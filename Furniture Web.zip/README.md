# Furniture-Website-PHP
Website from scratch using HTML, CSS, JS and PHP
<br>
<ul>
 <li><b>adminLoginForm<b> contains the HTML code for Admin login page.</li>
 <li><b>adminLogin<b> contains PHP code for admin authentication.</li>
 <li><b>adminLogout<b> contains PHP code for admin logout/session termination</li>
 <li><b>adminDashboard<b> contains code for Dashboard to be displayed for admin once logged in</li>
</ul>

